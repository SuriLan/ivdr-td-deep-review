---
name: ivdr-td-deep-review
description: IVDR/CE 体外诊断试剂技术文档包深度合规审核。当用户要求审核、检查、审阅 IVDR CE 技术文档（Technical Documentation）、项目文档包、按 Part A-M 组织的技术文档终稿，或提出"审核下这个项目/文档包"并希望按深度合规审核模式（全文档精读、跨文档一致性核查、问题按阻断/高/中/低/建议分级、Word 中文审核报告）执行时使用。也适用于对同一系列产品的多套技术文档（如生化试剂 CE 认证系列项目）重复审核。
---

# IVDR CE 技术文档深度审核

对体外诊断试剂 IVDR CE 技术文档终稿包（Part A–M 结构）做提交公告机构前的深度合规审核，交付 Word 中文审核报告。

## 流程总览

1. 盘点文件清单
2. 读取全部文档
3. 逐部分深度审核（Part A–M）
4. 跨文档一致性核查
5. 参考文献核验
6. 分级整理发现
7. 生成 Word 审核报告

## 第 1 步：盘点文件清单

- 递归列出目标文件夹：相对路径 + 大小 + 修改时间。路径过长导致 FullName 被截断时，用 `$_.FullName.Substring($root.Length + 1)` 输出相对路径
- 识别 Part A–M 结构；标记空占位文件、双版本并存、疑似重复文件、"声明可用但包内缺失"的文件
- 优先读取审核基准文件：`00 Cover Letter`、完整性检查表（如 MDF9003）
- 全程只读，不修改/删除/移动源文件

## 第 2 步：读取全部文档

- `.docx`：word skill 的 `scripts/read.py`，或 python-docx 提取段落/表格
- `.doc`（老格式）：本机无 LibreOffice → 用 Word COM（PowerShell `New-Object -ComObject Word.Application`，`OpenAndRepair` 打开后提取/另存）；WPS COM（`KWps.Application`）兜底，可透明解密 WPS 加密流
- `.pdf`：pymupdf 提取文本；扫描件（无文本层）先复制到本地再用 Read 工具按页渲染查看
- 本机已知陷阱（务必遵守）：
  - python 进程写含非 ASCII 文本的文件可能被加密（文件出现 `%TSD-Header` 内容或 `.IPGSD` 后缀）→ 中文/正式落盘优先用 Write 工具或 PowerShell/.NET 写入；python 只写纯 ASCII 或写 TSV 扩展名文件
  - python stdout 含中文的行可能被丢弃 → 让脚本把结果写入文件（UTF-8）再 Read，输出用纯 ASCII
  - 网络共享路径超过 260 字符触发 MAX_PATH 限制 → 用 `\\?\UNC\` 扩展前缀重读；读不到文件先查路径长度
  - 部分共享文件本身是 WPS 加密流（python 打不开）→ 用 Word COM / WPS COM 读取
- 每份文档读取后记录：文档 ID、标题、所属 Part、关键事实（产品名称、目录号、预期用途、仪器型号、日期、签名等锚点字段）

## 第 3 步：逐部分深度审核

- 完整读取 `references/ivdr-annex2-checklist.md`，按 Part A–M 逐一核对：内容完整性、IVDR Annex II / Annex I 符合性、适用标准引用、技术数据内部一致性
- 法规/分类核验可结合 `ivdr-regulation`、`ivdr-classification-codes` skill
- 每个 Part 的审核发现记录：文件定位（文档+章节/表格）、问题描述、法规依据、整改建议

## 第 4 步：跨文档一致性核查

- 按 checklist 中的关键字段清单建立一致性矩阵（产品名称/缩写、预期用途、IVR 分类与代码、目录号、标本类型、单位、测量范围、参考区间、仪器型号、制造商含曾用名、EU 代表、公告机构编号、证书号、文档编号、版本、日期、签名、文档互引）
- 同一字段在多个文档出现时逐处比对，不一致即记为发现

## 第 5 步：参考文献核验

- 核验每篇文献 PDF 的书目信息（标题/作者/期刊/年份）与正文引用清单一致；无法打开/无文本层者标注"待人工核验"
- 检查引用格式缺陷（缺卷页、版本日期不符）、单位/数字错误

## 第 6 步：分级整理发现

- 严重度分级定义见 checklist：阻断 / 高 / 中 / 低 / 建议
- 每条发现统一记录：编号（BL-01/H-01/M-01/L-01/S-01）、严重度、文件定位、法规依据、问题描述、整改建议
- 已知占位项（如"待 XX 输出"空文件）如实列为待办项，不作为新发现重复制造问题；疑似重复文件先判定关系（如配套层级 vs 重复）再定性

## 第 7 步：生成 Word 审核报告

- 完整读取 `references/report-structure.md`，按九章结构输出
- 创建 Word 必须遵循 word skill 完整流程：重新 Read `word/SKILL.md` → 建 outline.md（含引用核查表）→ 生成 → audit 校验（0 错误）→ render 渲染检查 → catalogue 更新目录
- 报告语言中文（文档/文件名引用保留英文原名），正式文书风格，禁用 emoji
- 报告保存到用户主项目目录，不写入被审文件夹；交付用 present_files

## 硬性约束

- 只读审核：不修改、不删除、不移动源文件
- 每条发现必须可溯源到具体文档与章节
- 不编造数据；无法核验处明确标注"待核验/待补充"
